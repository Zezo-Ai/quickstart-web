function Effect() {
    var self = this;

    this.meshes = [
        { file: "face.bsm2", anims: [
            { a: "static", t: 0 },
        ] },
        { file: "spider.bsm2", anims: [
            { a: "idle", t: 1466 },
            { a: "run", t: 8333 },
        ] },
    ];

    this.play = function() {
        var now = (new Date()).getTime();

        if(now > self.t && Api.isMouthOpen()) {
          Api.hideHint();
          Api.playSound("music.ogg",false,1);
          Api.meshfxMsg("animOnce", 1, 0, "run");
          Api.meshfxMsg("animLoop", 1, 1, "idle");
          self.t = now + 8333;
        }
    };

    this.init = function() {
        Api.meshfxMsg("spawn", 2, 0, "!glfx_FACE");

        Api.meshfxMsg("spawn", 0, 0, "face.bsm2");

        Api.meshfxMsg("spawn", 1, 0, "spider.bsm2");
        Api.meshfxMsg("animLoop", 1, 0, "idle");
        self.t = 0;

        self.faceActions = [self.play];
        Api.showHint("Open mouth");
        // Api.playVideo("frx",true,1);
        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();
        // Api.stopVideo("frx");
        Api.stopSound("music.ogg");
        self.init();
    };

    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());