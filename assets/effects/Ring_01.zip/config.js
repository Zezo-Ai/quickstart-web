bnb.scene.enableRecognizerFeature(bnb.FeatureID.RING);
let param = new bnb.FeatureParameter(2,0,0,0);
bnb.scene.addFeatureParam(bnb.FeatureID.RING, [param])
const rl = bnb.scene.getRenderList();

const rin = bnb.scene.getAssetManager().findRenderTarget("ColorCorrectionRT");
const ain = rin.getAttachments()[0];

const rout = bnb.scene.getAssetManager().findRenderTarget("cameraRT");
const aout = rout.getAttachments()[0];

const lightStreaks = require("bnb_js/light_streaks.js");

lightStreaks.BNBApplyLightStreaks(ain, aout, 0.99, [0.5, 0.5, 0.5, 1.0], bnb.BlendingMode.SCREEN);
